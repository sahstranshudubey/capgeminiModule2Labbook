export const environment = {
  production: true,
  user: {
    username:'x',
    password:'y'
  }
};
